package main

import (
	"flag"
	"fmt"
	"log"

	"github.com/labstack/echo/v4"

	"academy/internal/app"
	"academy/internal/handler"
)

func main() {
	port := flag.String("port", "8080", "default port: 8080")
	state := flag.String("state", "dev", "default state: dev")

	flag.Parse()

	em := &app.ErrorMessage{}
	em.Init()
	log.Printf("em: %+v", em)

	return

	c := &app.Configs{EM: em}
	c.InitWithState(state)
	fmt.Printf("config: %+v", c)

	e := echo.New()
	//e.Use(handler.Recover)
	//e.Use(middleware.RequestID())
	//e.Use(handler.LoggerData)
	//e.Use(handler.LoggerHandlerRequest)
	//e.Use(middleware.BodyDumpWithConfig(handler.BodyDumpConfig()))

	if err := handler.InitRoute(e, c); err != nil {
		log.Panicln("new routes error:", err)
		return
	}
	e.Logger.Fatal(e.Start(fmt.Sprintf(":%s", *port)))
}
