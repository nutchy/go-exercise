package app

import (
	"fmt"
	"log"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

type Configs struct {
	vn    *viper.Viper
	EM    *ErrorMessage
	State string
	Port  string

	EnablePing bool  `mapstructure:"enable_ping"`
	Mongo      Mongo `mapstructure:"mongo"`
}

type Mongo struct {
	Addresses []string `mapstructure:"addresses"`
	Username  string   `mapstructure:"username"`
	Password  string   `mapstructure:"password"`
	Database  string   `mapstructure:"database"`

	HasConnection bool
}

func (m *Mongo) bindingConnection() error {
	fmt.Println("binding mongo connection")
	m.HasConnection = true

	return nil
}

func (c *Configs) InitWithState(s *string) error {
	fn := fmt.Sprintf("config.%s", *s)
	log.Printf("filename: %s", fn)

	vn := viper.New()
	vn.AddConfigPath("./configs")
	vn.SetConfigName(fn)
	c.vn = vn

	if err := vn.ReadInConfig(); err != nil {
		return err
	}

	if err := c.binding(); err != nil {
		return err
	}

	vn.WatchConfig()
	vn.OnConfigChange(func(in fsnotify.Event) {
		if err := c.binding(); err != nil {
			return
		}

		log.Printf("\nnew config: %+v", c)
	})

	return nil
}

func (c *Configs) binding() error {
	if err := c.vn.Unmarshal(&c); err != nil {
		return err
	}

	// binding additional data
	if err := c.Mongo.bindingConnection(); err != nil {
		return err
	}
	return nil
}
