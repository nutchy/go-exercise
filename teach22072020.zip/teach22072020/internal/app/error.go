package app

import (
	"log"
	"reflect"
	"unicode"

	"github.com/spf13/viper"
)

type ErrorCode struct {
	Code    string `mapstructure:"code"`
	Message string `mapstructure:"message"`
}

func (e ErrorCode) Error() string {
	return e.Message
}

type ErrorMessage struct {
	Success  ErrorCode     `mapstructure:"success"`
	Standard ErrorStandard `mapstructure:"standard"`
	NotAllow ErrorNotAllow `mapstructure:"not_allow"`
}

type ErrorStandard struct {
	InternalServerError ErrorCode `mapstructure:"internal_server_error"`
	NotFound            ErrorCode `mapstructure:"not_found"`
	BadRequest          ErrorCode `mapstructure:"bad_request"`
}

type ErrorNotAllow struct {
	Age ErrorCode
}

func (e ErrorMessage) Init() error {
	vn := viper.New()
	vn.AddConfigPath("./configs")
	vn.SetConfigName("error")

	if err := vn.ReadInConfig(); err != nil {
		return err
	}

	//if err := vn.Unmarshal(&e); err != nil {
	//	return err
	//}

	// reflect
	log.Println(reflect.ValueOf(e).NumField())

	for i := 0; i < reflect.ValueOf(e).NumField(); i++ {
		field := reflect.ValueOf(e).Field(i)
		log.Println("field:", field.String())
		log.Println("kind:", field.Kind())
		log.Println("name:", field.Type().Name())

		us := underscore(field.Type().Field(i).Name)
		log.Println("underscore name:", us)
	}

	//for i, n := range reflect.ValueOf(e).Elem() {
	//
	//}

	return nil
}

func underscore(str string) string {
	runes := []rune(str)
	var out []rune
	for i := 0; i < len(runes); i++ {
		if i > 0 && (unicode.IsUpper(runes[i]) || unicode.IsNumber(runes[i])) && ((i+1 < len(runes) && unicode.IsLower(runes[i+1])) || unicode.IsLower(runes[i-1])) {
			out = append(out, '_')
		}
		out = append(out, unicode.ToLower(runes[i]))
	}
	return string(out)
}
