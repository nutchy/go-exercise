package student

import (
	"fmt"

	"academy/pkg/validator"
)

type ServiceA struct {
	repo repo
}

func NewServiceA(repo repo) *ServiceA {
	return &ServiceA{repo: repo}
}

type repo interface {
	GetUser(name string) string
}

func (s ServiceA) NumberOfStudents(room string) (int, error) {
	if room == "1" {
		return 10, nil
	}
	return 0, nil
}

func (s ServiceA) Grade(score int) string {
	switch {
	case score > 60 && score < 70:
		return "D"
	case score > 71 && score < 80:
		return "C"
	case score > 81 && score < 90:
		return "B"
	case score > 91:
		return "A"
	default:
		return "F"
	}
}

func (s ServiceA) GetStudentName(name string) string {
	allow, _ := validator.CustomValidator(validator.TypeAge, "9")
	if !allow {
		return "not allow"
	}
	return fmt.Sprintf("student name is %s", s.repo.GetUser(name))
}
