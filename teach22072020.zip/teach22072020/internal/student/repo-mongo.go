package student

type RepoMongo struct{}

func NewRepoMongo() *RepoMongo {
	return &RepoMongo{}
}

func (r RepoMongo) GetUser(name string) string {
	if name == "foo" {
		return "test"
	}
	return "xxxx"
}

func (r RepoMongo) Error() string {
	return ""
}
