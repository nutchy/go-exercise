package student

import (
	"net/http"
	"strconv"

	"github.com/labstack/echo/v4"

	"academy/internal/app"
	"academy/internal/utils"
)

type Endpoint struct {
	cv  *app.Configs
	srv school
}

func NewEndpoint(cv *app.Configs, srv school) *Endpoint {
	return &Endpoint{cv: cv, srv: srv}
}

type school interface {
	NumberOfStudents(room string) (int, error)
	Grade(score int) string
	GetStudentName(name string) string
}

func (e Endpoint) NumberOfStudents(c echo.Context) error {
	num, err := e.srv.NumberOfStudents("1")
	if err != nil {
		//return utils.Response(c, e.cv.EM.Standard.InternalServerError)
	}
	return utils.Response(c, err, utils.M{"count": num})
}

func (e Endpoint) Grade(c echo.Context) error {
	score, err := strconv.Atoi(c.Param("score"))
	if err != nil {
		return c.JSON(http.StatusBadRequest, map[string]interface{}{"error": err.Error()})
	}
	return c.JSON(http.StatusOK, map[string]interface{}{"score": score, "grade": e.srv.Grade(score)})
}

func (e Endpoint) Name(c echo.Context) error {
	return c.JSON(http.StatusOK, map[string]interface{}{"name": e.srv.GetStudentName("foo")})
}
