package student

type SchoolB struct{}

func NewSchoolB() *ServiceA {
	return &ServiceA{}
}

func (s SchoolB) NumberOfStudents(room string) (int, error) {
	if room == "1" {
		return 10, nil
	}
	return 0, nil
}

func (s SchoolB) Grade(score int) string {
	switch {
	case score > 50 && score < 60:
		return "D"
	case score > 61 && score < 70:
		return "C"
	case score > 71 && score < 80:
		return "B"
	case score > 81:
		return "A"
	default:
		return "F"
	}
}
