package student

type RepoMem struct{}

func NewRepoMem() *RepoMem {
	return &RepoMem{}
}

func (r RepoMem) GetUser(name string) string {
	if name == "foo" {
		return "bar"
	}
	return "test"
}
