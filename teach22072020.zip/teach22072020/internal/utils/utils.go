package utils

import (
	"net/http"

	"github.com/labstack/echo/v4"

	//"academy/internal/handler"
	"academy/internal/model"
)

type M map[string]interface{}

func Response(c echo.Context, err error, data ...interface{}) error {
	//ec := err.(handler.ErrorCode)
	res := model.BaseResponse{
		//Code:        ec.Code,
		//Description: ec.Message,
		Route: c.Request().URL.String(),
	}
	if len(data) > 0 {
		res.Data = data[0]
	}
	return c.JSON(http.StatusOK, res)
}
