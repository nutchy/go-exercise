package model

type BaseResponse struct {
	Code        string      `json:"code"`
	Description string      `json:"description"`
	Route       string      `json:"route"`
	Data        interface{} `json:"data,omitempty"`
}
