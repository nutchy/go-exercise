package handler

import (
	"net/http"

	"github.com/labstack/echo/v4"

	"academy/internal/app"
	"academy/internal/ping"
	"academy/internal/student"
)

type route struct {
	Group      string
	Path       string
	Method     string
	Endpoint   echo.HandlerFunc
	Middleware []echo.MiddlewareFunc
}

func InitRoute(e *echo.Echo, cv *app.Configs) error {
	studentRepo := student.NewRepoMongo()
	studentService := student.NewServiceA(studentRepo)
	//studentSchool := student.NewSchoolB()

	pingEndpoint := ping.NewEndpoint()
	studentEndpoint := student.NewEndpoint(cv, studentService)

	routes := []route{
		{
			Group:      "",
			Path:       "/health_check",
			Method:     http.MethodGet,
			Endpoint:   pingEndpoint.HealthCheck,
			Middleware: []echo.MiddlewareFunc{cv.PingNotFound},
		},
		{
			Group:      "student",
			Path:       "/number",
			Method:     http.MethodGet,
			Endpoint:   studentEndpoint.NumberOfStudents,
			Middleware: nil,
		},
		{
			Group:      "student",
			Path:       "/grade/:score",
			Method:     http.MethodGet,
			Endpoint:   studentEndpoint.Grade,
			Middleware: nil,
		},
		{
			Group:      "student",
			Path:       "/name",
			Method:     http.MethodGet,
			Endpoint:   studentEndpoint.Name,
			Middleware: nil,
		},
	}

	// http connection
	for _, rt := range routes {
		e.Group(rt.Group).Add(rt.Method, rt.Path, rt.Endpoint, rt.Middleware...)
	}
	return nil
}
