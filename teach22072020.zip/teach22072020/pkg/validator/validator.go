package validator

import (
	"errors"
	"strconv"
)

var (
	TypeString CustomerValidatorType = "string"
	TypeInt    CustomerValidatorType = "int"
	TypeAge    CustomerValidatorType = "age"
)

type CustomerValidatorType string

func CustomValidator(t CustomerValidatorType, value interface{}) (bool, error) {
	var v validator
	switch t {
	case TypeString:
		v = stringValidator{}
	case TypeInt:
		v = intValidator{}
	case TypeAge:
		v = ageValidator{}
	default:
		return false, errors.New("not declare")
	}
	return v.Validate(value)
}

type validator interface {
	Validate(value interface{}) (bool, error)
}

type stringValidator struct{}

func (sv stringValidator) Validate(value interface{}) (bool, error) {
	if value.(string) == "string" {
		return true, nil
	}
	return false, nil
}

type intValidator struct{}

func (iv intValidator) Validate(value interface{}) (bool, error) {
	if value.(int) == 1 {
		return true, nil
	}
	return false, nil
}

type ageValidator struct{}

func (av ageValidator) Validate(value interface{}) (bool, error) {
	age, err := strconv.Atoi(value.(string))
	if err != nil {
		return false, err
	}
	if age < 10 || age > 50 {
		return false, nil
	}
	return true, nil
}
