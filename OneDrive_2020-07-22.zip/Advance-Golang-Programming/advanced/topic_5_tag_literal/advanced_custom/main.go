package main

import (
	"bufio"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strconv"
	"strings"
	"time"

	log "github.com/sirupsen/logrus"
)

const (
	fixLengthTag       = "fixLength"
	fixLengthFormatTag = "fixLengthFormat"
)

var tz *time.Location

func main() {
	tz, _ = time.LoadLocation("Asia/Bangkok")

	//basicParse()
	advancedParse()
}

func basicParse() {
	f, err := os.Open(filepath.Join(".", "0991328424_13062017_STD.txt"))
	if err != nil {
		log.Errorln("unable to open fix length file")
		return
	}

	buff := bufio.NewScanner(f)
	buff.Split(bufio.ScanLines)

	var pf profile
	for buff.Scan() {
		b := buff.Bytes()

		switch string(b[0]) {
		case "H":
			h, err := parseProfileHeader(b)
			if err != nil {
				log.Errorln("unable to parse header:", err)
				continue
			}
			pf.Header = h
		case "D":
			d, err := parseProfileDetail(b)
			if err != nil {
				log.Errorln("unable to parse response detail:", err)
				continue
			}
			pf.Details = append(pf.Details, d)
		case "T":
			t, err := parseProfileTransaction(b)
			if err != nil {
				log.Errorln("unable to parse transaction:", err)
				continue
			}
			pf.Transaction = t
		}
	}

	log.Infof("header: %+v", pf.Header)
	for _, d := range pf.Details {
		log.Infof("detail: %+v", d)
	}
	log.Infof("transaction: %+v", pf.Transaction)
}

type profile struct {
	Header      profileHeader
	Details     []profileDetail
	Transaction profileTransaction
}

func (p profile) GenerateFixLength(name string) error {
	f, err := os.Create(filepath.Join("local", "path", name))
	if err != nil {
		return err
	}
	defer f.Close()

	// write header
	f.WriteString(p.Header.FixLength())
	f.WriteString("\n")

	// write body
	for _, b := range p.Details {
		f.WriteString(b.FixLength())
		f.WriteString("\n")
	}

	// write transaction footer
	f.WriteString(p.Transaction.FixLength())
	f.WriteString("\n")

	// sync file
	f.Sync()

	return nil
}

type profileHeader struct {
	RecordType     string
	SequenceNumber int
	BankCode       string
	CompanyAccount string
	CompanyName    string
	EffectiveDate  *time.Time
	ServiceCode    string
}

func (ph profileHeader) FixLength() string {
	return fmt.Sprintf(
		"%s%s%s%s%s%s%s%s",
		ph.RecordType,
		fmt.Sprintf("%06d", ph.SequenceNumber),
		fmt.Sprintf("%03s", ph.BankCode),
		ph.CompanyAccount,
		fmt.Sprintf("%-40s", ph.CompanyName),
		ph.EffectiveDate.Format("02012006"),
		fmt.Sprintf("%-8s", ph.ServiceCode),
		strings.Repeat(" ", 180),
	)
}

type profileTransaction struct {
	RecordType             string
	SequenceNumber         int
	BankCode               string
	CompanyAccount         string
	TotalDebitAmount       float64
	TotalDebitTransaction  int
	TotalCreditAmount      float64
	TotalCreditTransaction int
}

func (pt profileTransaction) FixLength() string {
	return fmt.Sprintf(
		"%s%s%s%s%s%s%s%s%s",
		pt.RecordType,
		fmt.Sprintf("%06d", pt.SequenceNumber),
		fmt.Sprintf("%03s", pt.BankCode),
		pt.CompanyAccount,
		fmt.Sprintf("%013s", amountToString(pt.TotalDebitAmount)),
		fmt.Sprintf("%06d", pt.TotalDebitTransaction),
		fmt.Sprintf("%013s", amountToString(pt.TotalCreditAmount)),
		fmt.Sprintf("%06d", pt.TotalCreditTransaction),
		strings.Repeat(" ", 198),
	)
}

type profileDetail struct {
	RecordType       string
	SequenceNumber   string
	BankCode         string
	CompanyAccount   string
	Payment          *time.Time
	CustomerName     string
	Ref1             string
	Ref2             string
	Ref3             string
	BranchNo         string
	TellerNo         string
	TransactionType  string
	TransactionCode  string
	ChequeNumber     string
	Amount           float64
	ChequeBankCode   string
	PayeeFeeSameZone string
	PayeeFeeDiffZone string
	NewChequeNo      string
}

func (pb profileDetail) FixLength() string {
	return fmt.Sprintf(
		"%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s",
		pb.RecordType,
		fmt.Sprintf("%06s", pb.SequenceNumber),
		fmt.Sprintf("%03s", pb.BankCode),
		pb.CompanyAccount,
		pb.Payment.Format("02012006"),
		pb.Payment.Format("150405"),
		fmt.Sprintf("%-50s", pb.CustomerName),
		fmt.Sprintf("%-20s", pb.Ref1),
		fmt.Sprintf("%-20s", pb.Ref2),
		fmt.Sprintf("%-20s", pb.Ref3),
		fmt.Sprintf("%04s", pb.BranchNo),
		fmt.Sprintf("%04s", pb.TellerNo),
		pb.TransactionType,
		fmt.Sprintf("%-3s", pb.TransactionCode),
		fmt.Sprintf("%-7s", pb.ChequeNumber),
		fmt.Sprintf("%013s", amountToString(pb.Amount)),
		fmt.Sprintf("%-3s", pb.ChequeBankCode),
		fmt.Sprintf("%-8s", pb.PayeeFeeSameZone),
		fmt.Sprintf("%-8s", pb.PayeeFeeDiffZone),
		strings.Repeat(" ", 51),
		fmt.Sprintf("%-10s", pb.NewChequeNo),
	)
}

func parseAmount(str string) (float64, error) {
	b := []byte(str)
	l := len(b) - 2
	n := b[0:l]
	d := b[l:]

	return strconv.ParseFloat(fmt.Sprintf("%s.%s", string(n), string(d)), 64)
}

func amountToString(a float64) string {
	return strings.Replace(fmt.Sprintf("%.2f", a), ".", "", -1)
}

func parseProfileHeader(b []byte) (profileHeader, error) {
	sn, err := strconv.Atoi(string(b[1:7]))
	if err != nil {
		return profileHeader{}, err
	}

	ed, err := time.Parse("02012006", strings.TrimSpace(string(b[60:68])))
	if err != nil {
		return profileHeader{}, err
	}

	rtn := profileHeader{
		RecordType:     string(b[0:1]),
		SequenceNumber: sn,
		BankCode:       string(b[7:10]),
		CompanyAccount: string(b[10:20]),
		CompanyName:    strings.TrimSpace(string(b[20:60])),
		EffectiveDate:  &ed,
		ServiceCode:    strings.TrimSpace(string(b[68:76])),
	}
	return rtn, nil
}

func parseProfileDetail(b []byte) (profileDetail, error) {
	pm, err := time.ParseInLocation("02012006150405", string(b[20:34]), tz)
	if err != nil {
		return profileDetail{}, err
	}

	am, err := parseAmount(string(b[163:176]))
	if err != nil {
		return profileDetail{}, err
	}

	rtn := profileDetail{
		RecordType:       string(b[0:1]),
		SequenceNumber:   string(b[1:7]),
		BankCode:         string(b[7:10]),
		CompanyAccount:   string(b[10:20]),
		Payment:          &pm,
		CustomerName:     strings.TrimSpace(string(b[34:84])),
		Ref1:             strings.TrimSpace(string(b[84:104])),
		Ref2:             strings.TrimSpace(string(b[104:124])),
		Ref3:             strings.TrimSpace(string(b[124:144])),
		BranchNo:         string(b[144:148]),
		TellerNo:         string(b[148:152]),
		TransactionType:  string(b[152:153]),
		TransactionCode:  strings.TrimSpace(string(b[153:156])),
		ChequeNumber:     string(b[156:163]),
		Amount:           am,
		ChequeBankCode:   string(b[176:179]),
		PayeeFeeSameZone: strings.TrimSpace(string(b[179:187])),
		PayeeFeeDiffZone: strings.TrimSpace(string(b[187:195])),
		NewChequeNo:      string(b[246:256]),
	}
	return rtn, nil
}

func parseProfileTransaction(b []byte) (profileTransaction, error) {
	sn, err := strconv.Atoi(string(b[1:7]))
	if err != nil {
		return profileTransaction{}, err
	}

	da, err := parseAmount(string(b[20:33]))
	if err != nil {
		return profileTransaction{}, err
	}

	dt, err := strconv.Atoi(string(b[33:39]))
	if err != nil {
		return profileTransaction{}, err
	}

	ca, err := parseAmount(string(b[39:52]))
	if err != nil {
		return profileTransaction{}, err
	}

	ct, err := strconv.Atoi(string(b[52:58]))
	if err != nil {
		return profileTransaction{}, err
	}

	rtn := profileTransaction{
		RecordType:             string(b[0:1]),
		SequenceNumber:         sn,
		BankCode:               string(b[7:10]),
		CompanyAccount:         string(b[10:20]),
		TotalDebitAmount:       da,
		TotalDebitTransaction:  dt,
		TotalCreditAmount:      ca,
		TotalCreditTransaction: ct,
	}
	return rtn, nil
}

func advancedParse() {
	f, err := os.Open(filepath.Join(".", "0991328424_13062017_STD.txt"))
	if err != nil {
		log.Errorln("unable to open fix length file")
		return
	}

	buff := bufio.NewScanner(f)
	buff.Split(bufio.ScanLines)

	//var pf profile
	var fl fixLength
	for buff.Scan() {
		str := buff.Text()

		switch str[:1] {
		case "H":
			var h profileHeaderWithTag
			if err := fl.Parse(str, &h); err != nil {
				log.Errorln("fix length parse error:", err)
				continue
			}
			log.Printf("header %+v", h)
		case "T":
			var t profileTransactionWithTag
			if err := fl.Parse(str, &t); err != nil {
				log.Errorln("fix length parse error:", err)
				continue
			}
			log.Printf("transaction: %+v", t)
		}

		//b := buff.Bytes()
		//
		//switch string(b[0]) {
		//case "H":
		//	h, err := parseProfileHeader(b)
		//	if err != nil {
		//		log.Errorln("unable to parse header:", err)
		//		continue
		//	}
		//	pf.Header = h
		//case "D":
		//	d, err := parseProfileDetail(b)
		//	if err != nil {
		//		log.Errorln("unable to parse response detail:", err)
		//		continue
		//	}
		//	pf.Details = append(pf.Details, d)
		//case "T":
		//	t, err := parseProfileTransaction(b)
		//	if err != nil {
		//		log.Errorln("unable to parse transaction:", err)
		//		continue
		//	}
		//	pf.Transaction = t
		//}
	}
}

type profileHeaderWithTag struct {
	RecordType     string     `fixLength:"0,1"`
	SequenceNumber int        `fixLength:"1,7"`
	BankCode       string     `fixLength:"7,10"`
	CompanyAccount string     `fixLength:"10,20"`
	CompanyName    string     `fixLength:"20,60"`
	EffectiveDate  *time.Time `fixLength:"60,68" fixLengthFormat:"02012006"`
	ServiceCode    string     `fixLength:"68,76"`
}

type profileTransactionWithTag struct {
	RecordType             string  `fixLength:"0,1"`
	SequenceNumber         int     `fixLength:"1,7"`
	BankCode               string  `fixLength:"7,10"`
	CompanyAccount         string  `fixLength:"10,20"`
	TotalDebitAmount       float64 `fixLength:"20,33"`
	TotalDebitTransaction  int     `fixLength:"33,39"`
	TotalCreditAmount      float64 `fixLength:"39,52"`
	TotalCreditTransaction int     `fixLength:"52,58"`
}

type fixLength struct{}

func (fl fixLength) Parse(str string, v interface{}) error {
	te := reflect.ValueOf(v).Type().Elem()
	ee := reflect.ValueOf(v).Elem()

	for i := 0; i < te.NumField(); i++ {
		f := te.Field(i)
		pos := f.Tag.Get(fixLengthTag)
		if pos == "" || pos == "-" {
			continue
		}

		start, end, err := fl.splitPosition(pos)
		if err != nil {
			continue
		}

		if len(str) <= start {
			continue
		}
		rtn := strings.TrimSpace(str[start:end])

		af := ee.FieldByName(f.Name)
		switch af.Kind() {
		case reflect.String:
			af.SetString(rtn)
		case reflect.Int:
			i, err := strconv.Atoi(rtn)
			if err != nil {
				continue
			}
			af.SetInt(int64(i))
		case reflect.Float32, reflect.Float64:
			i, err := strconv.ParseFloat(rtn, 64)
			if err != nil {
				continue
			}
			af.SetFloat(i)
		case reflect.Ptr:
			if f.Type.String() == "*time.Time" {
				fm := f.Tag.Get(fixLengthFormatTag)
				if fm == "" || fm == "-" {
					continue
				}

				d, err := time.Parse(fm, rtn)
				if err != nil {
					continue
				}
				af.Set(reflect.ValueOf(&d))
			}
		}
	}

	return nil
}

func (fl fixLength) splitPosition(s string) (int, int, error) {
	sp := strings.Split(s, ",")
	if len(sp) != 2 {
		return 0, 0, errors.New("invalid length")
	}

	start, err := strconv.Atoi(sp[0])
	if err != nil {
		return 0, 0, errors.New("unable to parse start position")
	}

	end, err := strconv.Atoi(sp[1])
	if err != nil {
		return 0, 0, errors.New("unable to parse end position")
	}
	return start, end, nil
}
