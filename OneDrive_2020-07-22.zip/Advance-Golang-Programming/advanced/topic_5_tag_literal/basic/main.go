package main

import (
	"encoding/json"
	"encoding/xml"
	"log"
	"strings"

	"github.com/dustin/go-humanize"
)

type data struct {
	FirstName string `json:"first_name" xml:"first_name,omitempty" validate:"required"`
	LastName  string `json:"last_name" xml:"last_name,omitempty" validate:"required"`
	Score     score  `json:"score" xml:"score" validate:"required"`
}

func main() {
	jsonUnmarshal()
	//jsonMarshal()
	//xmlUnmarshal()
	//xmlMarshal()
	//animalXmlUnmarshal()
}

func jsonUnmarshal() {
	str := `{"first_name":"foo","last_name":"bar","score":9861}`

	var d data
	if err := json.Unmarshal([]byte(str), &d); err != nil {
		log.Println("json unmarshal error:", err)
		return
	}

	log.Printf("data: %+v\n", d)
}

func jsonMarshal() {
	d := data{
		FirstName: "steve",
		LastName:  "parker",
		Score:     3237689,
	}

	rtn, err := json.Marshal(d)
	if err != nil {
		log.Println("json marshal error:", err)
		return
	}

	log.Println("data:", string(rtn))
}

func xmlUnmarshal() {
	str := `<data><first_name>foo</first_name><last_name>bar</last_name><score>40</score></data>`

	var d data
	if err := xml.Unmarshal([]byte(str), &d); err != nil {
		log.Println("xml unmarshal error:", err)
		return
	}

	log.Printf("data: %+v\n", d)
}

func xmlMarshal() {
	d := data{
		FirstName: "steve",
		LastName:  "parker",
		Score:     83239231,
	}

	rtn, err := xml.Marshal(d)
	if err != nil {
		log.Println("xml marshal error:", err)
		return
	}

	log.Println("data:", string(rtn))
}

type score int

func (s score) MarshalJSON() ([]byte, error) {
	return json.Marshal(humanize.Comma(int64(s)))
}

func (s score) MarshalXML(e *xml.Encoder, start xml.StartElement) error {
	return e.EncodeElement(humanize.Comma(int64(s)), start)
}

func (s score) Error() string {
	return ""
}

// ====================================================================

const (
	Unknown animal = iota
	Gopher
	Zebra
)

type animal int

func (a *animal) UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {
	var s string
	if err := d.DecodeElement(&s, &start); err != nil {
		return err
	}

	switch strings.ToLower(s) {
	case "gopher":
		*a = Gopher
	case "zebra":
		*a = Zebra
	default:
		*a = Unknown
	}
	return nil
}

func animalXmlUnmarshal() {
	data := `
	<animals>
		<animal>gopher</animal>
		<animal>armadillo</animal>
		<animal>zebra</animal>
		<animal>unknown</animal>
		<animal>gopher</animal>
		<animal>bee</animal>
		<animal>gopher</animal>
		<animal>zebra</animal>
	</animals>`

	var zoo struct {
		Animals []animal `xml:"animal"`
	}
	if err := xml.Unmarshal([]byte(data), &zoo); err != nil {
		log.Println("xml unmarshal error:", err)
		return
	}

	log.Printf("data: %+v", zoo)

	count := make(map[animal]int)
	for _, a := range zoo.Animals {
		count[a] += 1
	}

	log.Println("gopher:", count[Gopher])
	log.Println("zebra:", count[Zebra])
	log.Println("unknown:", count[Unknown])
}
