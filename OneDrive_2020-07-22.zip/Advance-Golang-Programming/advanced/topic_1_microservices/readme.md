# Microservice

kubernetes --> openshift

## docker
```dockerfile
# Use an official Python runtime as a parent image
FROM python:2.7-slim

# Set the working directory to /app
WORKDIR /app

# Copy the current directory contents into the container at /app
COPY . /app

# Install any needed packages specified in requirements.txt
RUN pip install --trusted-host pypi.python.org -r requirements.txt

# Make port 80 available to the world outside this container
EXPOSE 80

# Define environment variable
ENV NAME World

# Run app.py when the container launches
CMD ["python", "app.py"]
```

### dockerfile support parameters
- ADD
- COPY
- CMD
- ENV
- EXPOSE
- FROM
- LABEL
- RUN
- VOLUME
- WORKDIR

### command
- docker build -t {image name} .
- docker run {image name}
- docker ps (--all)
- docker stop {container id}
- docker run --detach --publish 8000:8000 go-hello

### workshops
1. write dockerfile to run basic application
2. write dockerfile to run http listener application to calculate grade

		A: more than 90			
		B: more than 80
		C: more than 70
		D: more than 60
		F: else	

## docker-compose
```yaml
version: '3.6'

services:
  nginx:
  	image: jwilder/nginx-proxy
	volumes:
	  - "/var/run/docker.sock:/tmp/docker.sock:ro"
	ports:
	  - 8080:80

  app:
	build: .
	expose:
	  - 3000
	links:
	  - nginx
	depends_on:
	  - mongodb
	environment:
	  CLIENT_ID: '123456'	 
	  
  mongodb:
  	image: mongodb
  	ports: 
  	  - 27017:27017  	  	       	
```

### command
- docker-compose build
- docker-compose up (-d)
- docker-compose logs (-f)
- docker-compose stop
- docker-compose down
- docker-compose ps

### workshops
1. write docker-compose to run basic application

2. write docker-compose with 2 golang application:

	2.1 interface application: has "/get_grade" endpoint to call to other service
	
	2.2 business application: write program with "/" endpoint receive "score" as json and return calculate grade
	
		A: more than 90		
		B: more than 80
		C: more than 70
		D: more than 60
		F: else	

## redis channel/mq		
- https://redis.io/topics/pubsub
- https://github.com/adjust/rmq		
		
### workshops
1. change the previous workshop from rest api to redis channel or mq  
