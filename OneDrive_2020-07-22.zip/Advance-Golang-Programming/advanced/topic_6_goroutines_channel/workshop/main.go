package main

import (
	"fmt"
	"net/http"
	"sync"
)

var urls = []string{
	"https://google.com",
	"https://tutorialedge.net",
	"https://twitter.com",
}

func callurl(url string, resChannel chan string, wg *sync.WaitGroup) {

	fmt.Println("start call site ", url)
	for i := 0; i < 10; i++ {
		resp, err := http.Get(url)
		if err != nil {
			fmt.Println(err)
			resChannel <- fmt.Sprint("error from site ", url)
		}
		//wg.Done() //try to comment
		//fmt.Println(resp.Status, " from ", url)
		resChannel <- fmt.Sprintf("%s from site %s", resp.Status, url)
	}
	wg.Done()
}

func homePage() {
	fmt.Println("HomePage Endpoint Hit")
	var wg sync.WaitGroup
	rc := make(chan string)

	wg.Add(3)
	go callurl(urls[0], rc, &wg)
	go callurl(urls[1], rc, &wg)
	go callurl(urls[2], rc, &wg)

	go func() {
		for r := range rc {
			fmt.Println("response in channel : ", r)
		}
	}()
	wg.Wait() //try to comment
	fmt.Println("Returning Response")
	close(rc)
}

func main() {
	homePage()
}
