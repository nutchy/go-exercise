package main

import (
"fmt"
"math/rand"
"sync"
)


func CalculateValue(values chan interface{},wg *sync.WaitGroup) {
	rd := rand.Int31()
	fmt.Println("Calculated Random Value: ", rd)
	values <- rd
	wg.Done()
}

func main() {
	fmt.Println("Go Channel Tutorial")

	var wg sync.WaitGroup
	values := make(chan interface{})

	for i:=0 ;i<10; i++{
		wg.Add(1)
		go CalculateValue(values, &wg)
	}

	go func(){
		for j:= range values{
			fmt.Println("value in channel : ", j.(int32))
		}
	}()

	wg.Wait()
	close(values)
}
