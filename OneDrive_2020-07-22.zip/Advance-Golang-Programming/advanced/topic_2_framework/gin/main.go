package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"net/http"
	"net/http/httputil"
	"sort"
	"strconv"
	"strings"
	"time"

	//"github.com/didip/tollbooth"
	//"github.com/didip/tollbooth/limiter"
	"github.com/fsnotify/fsnotify"
	"github.com/gin-gonic/gin"
	log "github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

type state string

const (
	stateLocal state = "dev"
	stateDEV   state = "dev"
	stateSIT   state = "sit"
	statePROD  state = "prod"
)

var cv constantViper

func main() {
	state := flag.String("state", "localhost", "set working environment")
	flag.Parse()

	cv.SetState(state)
	cv.Init()

	basicHttp()
	//middlewareHttp()
	//routerHttp()
	//versionHttp()
	//advancedMiddlewareHttp()
	//workshopHttp()
}

func basicHttp() {
	r := gin.Default()
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"message": 10})
	})
	r.Run()
}

func middlewareHttp() {
	r := gin.New()

	var m middleware
	r.Use(m.request)

	r.GET("/ping", pingEndpoint)
	r.POST("/hello", helloEndpoint)
	r.Run()
}

func routerHttp() {
	routes := []route{
		{
			Name:        "basic ping",
			Description: "ping/pong message for testing",
			Method:      "GET",
			Pattern:     "/ping",
			Endpoint:    pingEndpoint,
		},
	}

	r := gin.Default()
	for _, ro := range routes {
		r.Handle(ro.Method, ro.Pattern, ro.Endpoint)
	}
	r.Run()
}

func versionHttp() {
	routesV1 := []route{
		{
			Name:        "basic ping",
			Description: "ping/pong message for testing",
			Method:      "GET",
			Pattern:     "/ping",
			Endpoint:    pingEndpoint,
		},
	}

	routesV2 := []route{
		{
			Name:        "basic ping v2",
			Description: "ping/pong message for testing",
			Method:      "GET",
			Pattern:     "/ping",
			Endpoint:    pingV2Endpoint,
		},
	}

	r := gin.Default()

	v1 := r.Group("/v1")
	for _, ro := range routesV1 {
		v1.Handle(ro.Method, ro.Pattern, ro.Endpoint)
	}

	v2 := r.Group("/v2")
	for _, ro := range routesV2 {
		v2.Handle(ro.Method, ro.Pattern, ro.Endpoint)
	}

	r.Run()
}

func advancedMiddlewareHttp() {
	routes := []route{
		{
			Name:        "basic ping",
			Description: "ping/pong message for testing",
			Method:      "GET",
			Pattern:     "/ping",
			Endpoint:    pingEndpoint,
			AuthenLevel: 0,
		},
		{
			Name:        "hello",
			Description: "hello message, return response to say hello to request name",
			Method:      "POST",
			Pattern:     "/hello",
			Endpoint:    helloEndpoint,
			AuthenLevel: 1,
		},
	}

	r := gin.Default()

	var m middleware
	for _, ro := range routes {
		r.Handle(ro.Method, ro.Pattern, m.handleAuthLevel(ro.AuthenLevel, ro.Endpoint)...)
	}
	r.Run()
}

func taskOneEndpoint(c *gin.Context) {
	p := point(c.Query("point"))
	res, err := p.CalculateGrade()
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"message": "invalid point"})
		return
	}
	c.JSON(http.StatusOK, res)
}

type grade struct {
	Point int    `json:"point"`
	Grade string `json:"grade"`
}

type point string

func (p point) CalculateGrade() (grade, error) {
	pi, err := strconv.Atoi(string(p))
	if err != nil {
		return grade{}, err
	}

	switch {
	case pi > 60 && pi < 70:
		return grade{pi, "D"}, nil
	case pi > 71 && pi < 80:
		return grade{pi, "C"}, nil
	case pi > 81 && pi < 90:
		return grade{pi, "B"}, nil
	case pi > 91:
		return grade{pi, "A"}, nil
	}
	return grade{pi, "F"}, nil
}

func workshopHttp() {
	r := gin.Default()
	r.GET("/task_one", taskOneEndpoint)

	r.POST("/task_two", func(c *gin.Context) {
		var req struct {
			Message string `json:"message"`
		}
		if err := json.NewDecoder(c.Request.Body).Decode(&req); err != nil {
			c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"message": "invalid request"})
			return
		}
		defer c.Request.Body.Close()

		ws := strings.Split(req.Message, " ")
		sort.Sort(byLength(ws))

		type resp struct {
			Word   string `json:"word"`
			Length int    `json:"length"`
		}

		var res []resp
		for _, w := range ws {
			res = append(res, resp{w, len(w)})
		}
		c.JSON(http.StatusOK, res)
	})
	r.Run(":8000")
}

type byLength []string

func (l byLength) Len() int {
	return len(l)
}

func (l byLength) Swap(i, j int) {
	l[i], l[j] = l[j], l[i]
}

func (l byLength) Less(i, j int) bool {
	return len(l[i]) < len(l[j])
}

func pingEndpoint(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "pong"})
}

func pingV2Endpoint(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "pong v2"})
}

func helloEndpoint(c *gin.Context) {
	var req struct {
		Name string `json:"name"`
	}
	if err := json.NewDecoder(c.Request.Body).Decode(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "unable to parse request"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": fmt.Sprint("Hello, ", req.Name)})
}

type route struct {
	Name        string
	Description string
	Method      string
	Pattern     string
	Endpoint    gin.HandlerFunc
	AuthenLevel int
}

type middleware struct{}

func (m middleware) handleAuthLevel(auth int, endpoint gin.HandlerFunc) []gin.HandlerFunc {
	var rtn []gin.HandlerFunc
	switch auth {
	case 0: // grant access to everyone
	case 1: // check for session
		rtn = append(rtn, m.verifySession)
	case 2: // handle rate limit and check for session
		//rtn = append(rtn, m.rateLimit(), m.verifySession)
	case 3: // handle under maintenance
		rtn = append(rtn, m.maintenance)
	}
	rtn = append(rtn, endpoint)

	return rtn
}

func (m middleware) request(c *gin.Context) {
	start := time.Now()
	dump, err := httputil.DumpRequest(c.Request, true)
	if err != nil {
		log.Errorln("[request middleware] unable to dump request:", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": "unable to parse request"})
		return
	}

	// prevent log binary file, eg. upload image file
	ct := c.Request.Header.Get("Content-Type")
	if strings.HasPrefix(ct, "application/json") {
		log.Infof("[request middleware] request: %s", dump)
	}

	c.Next()

	log.Infof(
		"[request middleware] Completed %s %s %v %s in %v\n",
		c.Request.Method,
		c.Request.URL.Path,
		c.Writer.Status(),
		http.StatusText(c.Writer.Status()),
		time.Since(start),
	)
}

func (m middleware) verifySession(c *gin.Context) {
	// assume check session from redis
	session := false
	log.Infoln("verify session:", session)

	if !session {
		//c.Abort()
		//c.JSON(http.StatusForbidden, gin.H{"message": "you don't have authorize to call this method."})

		// you can call abort like this
		c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"message": "you don't have authorize to call this method."})
		return
	}
	c.Next()
}

//func (m middleware) rateLimit() gin.HandlerFunc {
//	// 1 request per second, 60 request per minute
//	lmt := tollbooth.NewLimiter(1, &limiter.ExpirableOptions{DefaultExpirationTTL: time.Hour})
//
//	return func(c *gin.Context) {
//		//addr := strings.Split(c.Request.RemoteAddr, ":")[0]
//		addr := "127.0.0.1"
//		if lmt.LimitReached(addr) {
//			c.AbortWithStatusJSON(http.StatusTooManyRequests, gin.H{"message": "rate limit reached"})
//			return
//		}
//		c.Next()
//	}
//}

func (m middleware) maintenance(c *gin.Context) {
	if cv.Maintenance {
		c.AbortWithStatusJSON(http.StatusUnprocessableEntity, gin.H{"message": "service under maintenance"})
		return
	}
	c.Next()
}

type constantViper struct {
	State       state
	ProjectCode string
	Maintenance bool
}

func (cv *constantViper) SetState(s *string) {
	switch *s {
	case "local", "localhost", "l":
		cv.State = stateLocal
	case "dev", "develop", "development", "d":
		cv.State = stateDEV
	case "sit", "staging", "s":
		cv.State = stateSIT
	case "prod", "production", "p":
		cv.State = statePROD
	default:
		cv.State = stateLocal
	}
}

func (cv *constantViper) Init() {
	viper.SetConfigFile("config.yml")
	viper.AddConfigPath(".")
	if err := viper.ReadInConfig(); err != nil {
		panic(err)
	}

	cv.binding()

	viper.WatchConfig()
	viper.OnConfigChange(func(e fsnotify.Event) {
		log.Infoln("config file changed:", e.Name)
		cv.binding()
	})
}

func (cv *constantViper) binding() {
	sub := viper.Sub(string(cv.State))

	cv.ProjectCode = sub.GetString("project_code")
	cv.Maintenance = sub.GetBool("maintenance")
}
