# RESTful APIs

## go module
- GO111MODULE=on go mod init {project-name}
- GO111MODULE=on go mod tidy
- GO111MODULE=on go mod vendor

## suggest 3rd party library
- https://github.com/urfave/negroni
- https://github.com/gin-gonic/gin
- https://github.com/go-chi/chi

## gin

```go
package main

import "github.com/gin-gonic/gin"

func main() {
	r := gin.Default()
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "pong",
		})
	})
	r.Run() // listen and serve on 0.0.0.0:8080
}
```

### Using GET, POST, PUT, PATCH, DELETE and OPTIONS
```go
func main() {
	// Disable Console Color
	// gin.DisableConsoleColor()

	// Creates a gin router with default middleware:
	// logger and recovery (crash-free) middleware
	router := gin.Default()

	router.GET("/someGet", getting)
	router.POST("/somePost", posting)
	router.PUT("/somePut", putting)
	router.DELETE("/someDelete", deleting)
	router.PATCH("/somePatch", patching)
	router.HEAD("/someHead", head)
	router.OPTIONS("/someOptions", options)

	// By default it serves on :8080 unless a
	// PORT environment variable was defined.
	router.Run()
	// router.Run(":3000") for a hard coded port
}
```

### Using middleware
```go
func main() {
	// Creates a router without any middleware by default
	r := gin.New()

	// Global middleware
	// Logger middleware will write the logs to gin.DefaultWriter even if you set with GIN_MODE=release.
	// By default gin.DefaultWriter = os.Stdout
	r.Use(gin.Logger())

	// Recovery middleware recovers from any panics and writes a 500 if there was one.
	r.Use(gin.Recovery())

	// Per route middleware, you can add as many as you desire.
	r.GET("/benchmark", MyBenchLogger(), benchEndpoint)

	// Authorization group
	// authorized := r.Group("/", AuthRequired())
	// exactly the same as:
	authorized := r.Group("/")
	// per group middleware! in this case we use the custom created
	// AuthRequired() middleware just in the "authorized" group.
	authorized.Use(AuthRequired())
	{
		authorized.POST("/login", loginEndpoint)
		authorized.POST("/submit", submitEndpoint)
		authorized.POST("/read", readEndpoint)

		// nested group
		testing := authorized.Group("testing")
		testing.GET("/analytics", analyticsEndpoint)
	}

	// Listen and serve on 0.0.0.0:8080
	r.Run(":8080")
}
```

```go
func requestMiddleware(c *gin.Context) {
	start := time.Now()
	dump, err := httputil.DumpRequest(c.Request, true)
	if err != nil {
		log.Errorln("[request middleware] unable to dump request:", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": "unable to parse request"})
		return
	}
	log.Infof("[request middleware] request: %s", dump)

	c.Next()

	log.Infof(
		"[request middleware] Completed %s %s %v %s in %v\n",
		c.Request.Method,
		c.Request.URL.Path,
		c.Writer.Status(),
		http.StatusText(c.Writer.Status()),
		time.Since(start),
	)
}
```

### router 
```go
type route struct {
	Name        string
	Description string
	Method      string
	Pattern     string
	Endpoint    gin.HandlerFunc
}

var routes = []route{
	{
        Name:        "basic ping",
        Description: "ping/pong message for testing",
        Method:      "GET",
        Pattern:     "/ping",
        Endpoint:    pingEndpoint,
    },
}

func main() {
	r := gin.Default()
    for _, ro := range routes {
        r.Handle(ro.Method, ro.Pattern, ro.Endpoint)
    }
    r.Run()
}
```

### version
```go
func main() {
	r := gin.Default()
    v1 := r.Group("/v1")
    for _, ro := range routesV1 {
        v1.Handle(ro.Method, ro.Pattern, ro.Endpoint)
    }
    r.Run()
}
```

### auth level
```go
func (m middleware) handleAuthLevel(auth int, endpoint gin.HandlerFunc) []gin.HandlerFunc {
	var rtn []gin.HandlerFunc
	switch auth {
	case 0:
		// grant access to everyone
	case 1:
		// check for session
		rtn = append(rtn, m.verifySession)
	case 2:
		// handle rate limit and check for session
		rtn = append(rtn, m.rateLimit(), m.verifySession)
	}
	rtn = append(rtn, endpoint)

	return rtn
}
```

### rate limiter
```go
func (m middleware) rateLimit() gin.HandlerFunc {
	// 1 request per second, 60 request per minute
	lmt := tollbooth.NewLimiter(1, &limiter.ExpirableOptions{DefaultExpirationTTL: time.Hour})

	return func(c *gin.Context) {
		//addr := strings.Split(c.Request.RemoteAddr, ":")[0]
		addr := "127.0.0.1"
		if lmt.LimitReached(addr) {
			c.AbortWithStatusJSON(http.StatusTooManyRequests, gin.H{"message": "rate limit reached"})
			return
		}
		c.Next()
	}
}
```

### viper
```go
type constantViper struct {
	State       state
	ProjectCode string
	Maintenance bool
}

func (cv *constantViper) SetState(s *string) {
	switch *s {
	case "local", "localhost", "l":
		cv.State = stateLocal
	case "dev", "develop", "development", "d":
		cv.State = stateDEV
	case "sit", "staging", "s":
		cv.State = stateSIT
	case "prod", "production", "p":
		cv.State = statePROD
	default:
		cv.State = stateLocal
	}
}

func (cv *constantViper) Init() {
	viper.SetConfigFile("config.yml")
	viper.AddConfigPath(".")
	if err := viper.ReadInConfig(); err != nil {
		panic(err)
	}

	cv.binding()

	viper.WatchConfig()
	viper.OnConfigChange(func(e fsnotify.Event) {
		log.Infoln("config file changed:", e.Name)
		cv.binding()
	})
}

func (cv *constantViper) binding() {
	sub := viper.Sub(string(cv.State))

	cv.ProjectCode = sub.GetString("project_code")
	cv.Maintenance = sub.GetBool("maintenance")
}
```

## project structure
- https://github.com/golang-standards/project-layout

### folders/packages
- configs
- deployment
- internal
- pkg
- vendor

### workshop
write a golang with folder structure including: configuration, router
- port can be configurable
- configuration file can be reload in real time
- multi stage of configuration file with difference value
- have multiple endpoint
- `/merchant` endpoint can be enable/disable via config
	
| Name                 | Method | Endpoint                      | Response JSON                                                           |
|----------------------|--------|-------------------------------|-------------------------------------------------------------------------|
| Ping                 | GET    | /v1/ping                      | {"message":"pong"}                                                      |
| Calculate Grade      | GET    | /v1/calculate_grade?score=100 | {"score":100,"grade":"A"}                                               |
| Merchant Register    | POST   | /v1/merchant/register         | {"id":"123456"}                                                         |
| Merchant Information | POST   | /v1/merchant/information      | {"id":"123456","name":"test","username":"generate","password":"123456"} |
| Merchant Update      | POST   | /v1/merchant/update			| {"id":"123456"}                                                         |
| Merchant Delete      | POST   | /v1/merchant/delete           |                                                                         |

### merchant field
- Name
- Username (auto generate)
- Password (auto generate)
