package main

import (
	"context"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"time"

	"Advance-Golang-Programming/advanced/topic_7_unit_test/structure/internal/api"
	"Advance-Golang-Programming/advanced/topic_7_unit_test/structure/internal/config"
	"Advance-Golang-Programming/advanced/topic_7_unit_test/structure/internal/db"
	"Advance-Golang-Programming/advanced/topic_7_unit_test/structure/pkg/klog"
)

var log = klog.WithPrefix("main")

func main() {
	defer klog.Close()

	port := flag.String("port", "8080", "default port: 8080")
	stage := flag.String("stage", "dev", "product stage: local/dev/sit/prod")
	configPath := flag.String("config", "configs", "configuration path")
	flag.Parse()

	// override config if provide by environment
	if s := os.Getenv("CONFIG_STATE"); s != "" {
		*stage = s
	}

	*stage = config.ParseStage(*stage)
	conf := &config.Config{}
	if err := conf.Init(*stage, *configPath); err != nil {
		panic(err)
	}

	log.Printf("config: %+v", conf)

	// Context
	glbCtx, glbCtxCancel := context.WithCancel(context.Background())

	dbConn, err := db.Init(conf.Database)
	if err != nil {
		log.Panicln(err)
	}
	defer dbConn.Close()

	route := api.Init(glbCtx, conf, dbConn)
	server := http.Server{
		Addr:    fmt.Sprintf(":%s", *port),
		Handler: route,
	}

	go func() {
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Panicln(err)
		}
	}()

	// Trap SIGTERM and SIGINT signals for graceful shutdown
	stopChan := make(chan os.Signal, 1)
	signal.Notify(stopChan, os.Kill, os.Interrupt)

	// Graceful shutdown
	log.Infof("%s signal received. Exiting", <-stopChan)
	sdCtx, sdCtxCancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer sdCtxCancel()

	if err := server.Shutdown(sdCtx); err != nil && err != http.ErrServerClosed {
		log.Infof("HTTP server graceful shutdown error: %v", err)
	}
	log.Infof("HTTP server closed")

	// Shutdown all background workers
	log.Infof("Waiting for all workers to stop")
	glbCtxCancel() // Notify all background workers to stop

	// TODO: Graceful shutdown background workers here if need
	log.Infof("All workers stopped")
}
