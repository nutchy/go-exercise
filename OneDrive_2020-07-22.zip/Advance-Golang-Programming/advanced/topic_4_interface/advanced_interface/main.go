package main

import (
	"errors"
	"log"
)

func main() {
	//merchantInterfaceUsage()
	customValidatorInterfaceUsage("age")
}

// ==================================================================

var merchantDB []merchant

func merchantInterfaceUsage() {
	repo := memoryRepo{}
	serv := newService(repo)

	if err := serv.Register("foo", "bar"); err != nil {
		log.Println("merchant register error:", err)
		return
	}
	log.Println("register merchant success")

	m, err := serv.Information(1)
	if err != nil {
		log.Println("merchant information error:", err)
		return
	}
	log.Printf("merchant: %+v", m)

	newData := merchant{Name: "john doe", Address: "USA"}
	if err := serv.Update(1, newData); err != nil {
		log.Println("merchant update error:", err)
		return
	}

	m, err = serv.Information(1)
	if err != nil {
		log.Println("merchant information error:", err)
		return
	}
	log.Printf("merchant: %+v", m)

	//
	//if err := serv.Delete(1); err != nil {
	//	log.Println("merchant delete error:", err)
	//	return
	//}
}

type merchant struct {
	ID      int
	Name    string
	Address string
}

type merchantRepository interface {
	MerchantInsert(merchant) error
	FindMerchantByID(int) (merchant, error)
	UpdateMerchantByID(id int, m merchant) error
}

type service struct {
	repo merchantRepository
}

func newService(repo merchantRepository) *service {
	return &service{repo: repo}
}

func (s service) Register(name, address string) error {
	m := merchant{
		ID:      1,
		Name:    name,
		Address: address,
	}
	if err := s.repo.MerchantInsert(m); err != nil {
		return err
	}
	return nil
}

func (s service) Information(id int) (merchant, error) {
	m, err := s.repo.FindMerchantByID(id)
	if err != nil {
		return merchant{}, err
	}
	return m, nil
}

func (s service) Update(id int, m merchant) error {
	return s.repo.UpdateMerchantByID(id, m)
}

func (s service) Delete(id int) error {
	return nil
}

// ==================================================================

type memoryRepo struct{}

func (mr memoryRepo) MerchantInsert(m merchant) error {
	merchantDB = append(merchantDB, m)
	return nil
}

func (mr memoryRepo) FindMerchantByID(id int) (merchant, error) {
	for _, m := range merchantDB {
		if m.ID == id {
			return m, nil
		}
	}
	return merchant{}, nil
}

func (mr memoryRepo) UpdateMerchantByID(id int, m merchant) error {
	for i := 0; i <= len(merchantDB); i++ {
		if merchantDB[i].ID == id {
			merchantDB[i].Name = m.Name
			merchantDB[i].Address = m.Address
			//merchantDB[i] = m
			return nil
		}
	}
	return nil
}

func (mr memoryRepo) DeleteMerchantByID(id int) error {
	return nil
}

// ==================================================================

func customValidatorInterfaceUsage(name string) {
	var validate validator
	switch name {
	case "string":
		validate = stringValidator{}
	case "number":
		validate = numberValidator{}
	case "email":
		validate = emailValidator{}
	case "age":
		validate = ageValidator{}
	default:
		panic("invalid validator type")
	}

	valid, err := validate.Validate(10)
	if !valid && err != nil {
		log.Println("validate error:", err)
		return
	}
	log.Println("validate:", valid)
}

type validator interface {
	Validate(interface{}) (bool, error)
}

type stringValidator struct{}

func (v stringValidator) Validate(val interface{}) (bool, error) {
	if val == "" {
		return false, errors.New("cannot be blank")
	}
	return true, nil
}

type numberValidator struct{}

func (v numberValidator) Validate(val interface{}) (bool, error) {
	if _, ok := val.(int); !ok {
		return false, errors.New("data is not an integer")
	}

	return true, nil
}

type emailValidator struct{}

func (v emailValidator) Validate(val interface{}) (bool, error) {
	return true, nil
}

type ageValidator struct{}

func (v ageValidator) Validate(val interface{}) (bool, error) {
	age, ok := val.(int)
	if !ok {
		return false, errors.New("data is not an integer")
	}
	if age < 20 {
		return false, errors.New("age under 20")
	}
	return true, nil
}

type kindValidator struct{}
