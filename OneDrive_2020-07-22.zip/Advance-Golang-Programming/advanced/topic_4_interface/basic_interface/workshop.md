### workshops
1. correct the code: https://play.golang.org/p/7_xjfr6S1zc
2. correct the code: https://play.golang.org/p/3KIIad2kpe8
