package main

import (
	"encoding/json"
	"log"
	"net/http"
	"sort"
	"strconv"
	"strings"

	"github.com/gorilla/mux"
)

func main() {
	r := mux.NewRouter()
	r.HandleFunc("/task_one", taskOne)
	r.HandleFunc("/task_two", taskTwo)

	http.ListenAndServe(":8000", r)
}

// task one: calculate grade
func taskOne(w http.ResponseWriter, r *http.Request) {
	point := r.URL.Query().Get("point")
	pi, err := strconv.Atoi(point)
	if err != nil {
		log.Println("invalid point")
		jsonResponse(w, http.StatusBadRequest, nil)
		return
	}

	grade := "F"
	switch {
	case pi > 60 && pi < 70:
		grade = "D"
	case pi > 71 && pi < 80:
		grade = "C"
	case pi > 81 && pi < 90:
		grade = "B"
	case pi > 91:
		grade = "A"
	}

	res := struct {
		Point int    `json:"point"`
		Grade string `json:"grade"`
	}{pi, grade}
	jsonResponse(w, http.StatusOK, res)
}

// task two: separate paragraph message and sort wording by length as response
func taskTwo(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Message string `json:"message"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonResponse(w, http.StatusBadRequest, nil)
		return
	}
	defer r.Body.Close()

	ws := strings.Split(req.Message, " ")
	sort.Sort(byLength(ws))

	type resp struct {
		Word   string `json:"word"`
		Length int    `json:"length"`
	}

	var res []resp
	for _, w := range ws {
		res = append(res, resp{w, len(w)})
	}
	jsonResponse(w, http.StatusOK, res)
}

type byLength []string

func (l byLength) Len() int {
	return len(l)
}

func (l byLength) Swap(i, j int) {
	l[i], l[j] = l[j], l[i]
}

func (l byLength) Less(i, j int) bool {
	return len(l[i]) < len(l[j])
}

func jsonResponse(w http.ResponseWriter, status int, v interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)

	if err := json.NewEncoder(w).Encode(v); err != nil {
		log.Println("encoding json as response error:", err)
	}
}
