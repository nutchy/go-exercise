package main

import (
	"fmt"
	"net/http"

	"gopkg.in/mgo.v2"
)

func main() {
	hello := func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("hello from docker!!!"))
	}

	http.HandleFunc("/", hello)
	http.HandleFunc("/query", query)
	http.ListenAndServe(":8000", nil)

	fmt.Println("run jaaaaaa")
}

func query(w http.ResponseWriter, r *http.Request) {
	sess, err := mgo.Dial("mongodb://root:example@mongo:27017")
	if err != nil {
		fmt.Fprintf(w, "dial error: %s", err)
		return
	}
	defer sess.Close()

	names, err := sess.DatabaseNames()
	if err != nil {
		fmt.Fprintf(w, "get db name error: %s", err)
		return
	}
	fmt.Fprintf(w, "names: %v", names)
}
