# Prepare computer
- golang package
- mongodb
- redis

** remark: any use of docker is fine.

## Recommended IDE
- goland (https://www.jetbrains.com/go/)
- studio 3T (https://studio3t.com/)
- git bash (for windows)
- iterms (for mac)

---

## Basic learning
- udemy
- tour of go (https://tour.golang.org/)
- mongodb tutorials (https://www.tutorialspoint.com/mongodb/)
- mongodb basic (https://www.codeproject.com/Articles/828392/Basics-of-MongoDB)
- package manager
- redis basic (https://redis.io/topics/quickstart)

---

## Golang recommended package
- gin (https://github.com/gin-gonic/gin)
- mgo (https://github.com/globalsign/mgo)
- log (https://github.com/sirupsen/logrus)
- redis (https://github.com/go-redis/redis)
- decimal (https://github.com/shopspring/decimal)

---

## Basic golang command
- go run
- go build
- go get ...
- go test

---

## Package manager
- govendor (https://github.com/kardianos/govendor)
- dep (https://github.com/golang/dep)

---
