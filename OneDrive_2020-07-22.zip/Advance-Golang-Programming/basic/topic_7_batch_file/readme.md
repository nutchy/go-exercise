# Batch File Generation

- fix length

```go
type profile struct {
	Header         profileHeader
	RequestDetail  []profileRequestDetail
	ResponseDetail []profileResponseDetail
	Transaction    profileTransaction
}

func (p profile) GenerateFixLength(name string) error {
	f, err := os.Create(filepath.Join("local", "path", name))
	if err != nil {
		return err
	}
	defer f.Close()

	// write header
	f.WriteString(p.Header.FixLength())
	f.WriteString("\n")

	// write body
	for _, b := range p.RequestDetail {
		f.WriteString(b.FixLength())
		f.WriteString("\n")
	}

	// write transaction footer
	f.WriteString(p.Transaction.FixLength())
	f.WriteString("\n")

	// sync file
	f.Sync()

	return nil
}
```

```go
type profileHeader struct {
	RecType      string
	SysDate      *time.Time
	BusinessDate string
	SrcAppID     string
	FileType     string
	FileSeqNum   int
}

func (ph profileHeader) FixLength() string {
	return fmt.Sprintf(
		"%s%s%s%s%s%s%s",
		"H01",
		fmt.Sprintf("%-33s", ph.SysDate.Format("2006-01-02T15:04:05")),
		fmt.Sprintf("%-10s", ph.BusinessDate),
		fmt.Sprintf("%-5s", ph.SrcAppID),
		fmt.Sprintf("%-8s", ph.FileType),
		fmt.Sprintf("%06d", ph.FileSeqNum),
		strings.Repeat(" ", 485),
	)
}
```

```go
func parseProfileHeader(str string) (profileHeader, error) {
	b := []byte(str)

	sd, err := time.Parse("2006-01-02T15:04:05", strings.TrimSpace(string(b[3:36])))
	if err != nil {
		return profileHeader{}, err
	}

	sn, err := strconv.Atoi(string(b[59:65]))
	if err != nil {
		return profileHeader{}, err
	}

	ph := profileHeader{
		RecType:      string(b[0:3]),
		SysDate:      &sd,
		BusinessDate: strings.TrimSpace(string(b[36:46])),
		SrcAppID:     strings.TrimSpace(string(b[46:51])),
		FileType:     strings.TrimSpace(string(b[51:59])),
		FileSeqNum:   sn,
	}
	return ph, nil
}
```
