package main

import (
	"flag"
	"os"
	"time"

	log "github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

var (
	tz *time.Location
	cv constantViper
)

type state string

const (
	stateLocal state = "dev"
	stateDEV   state = "dev"
	stateSIT   state = "sit"
	statePROD  state = "prod"
)

func main() {
	state := flag.String("state", "localhost", "set working environment")
	api := flag.String("api", "", "set api name")
	date := flag.String("date", time.Now().Format("20060102"), "target date, format: 20060102, default: time now")

	flag.Parse()

	// working in time zone "Bangkok"
	tz, _ = time.LoadLocation("Asia/Bangkok")

	d, err := time.ParseInLocation("20060102", *date, tz)
	if err != nil {
		log.Errorln("unable to parse date flag:", *date, err)
		return
	}

	// init constant from config file
	cv.SetState(state)
	cv.Init()

	r := reporting{Date: &d}
	switch *api {
	case "reconcile":
		if err := reconcile(&d); err != nil {
			log.Errorln("perform reconcile error:", d, err)
			os.Exit(1)
		}
	case "merchant-report-daily":
		if err := r.MerchantDaily(); err != nil {
			log.Errorln("perform merchant report daily error:", d, err)
			os.Exit(1)
		}
	case "merchant-report-monthly":
		if err := r.MerchantMonthly(); err != nil {
			log.Errorln("perform merchant report daily error:", d, err)
			os.Exit(1)
		}
	default:
		log.Warnln("api not found, mistyping maybe?", *api)
	}

	log.Infof("running api %s success", *api)
	os.Exit(0)
}

func reconcile(d *time.Time) error {
	return nil
}

type reporting struct {
	Date *time.Time
}

func (r reporting) MerchantDaily() error {
	return nil
}

func (r reporting) MerchantMonthly() error {
	return nil
}

type constantViper struct {
	State       state
	ProjectCode string
}

func (cv *constantViper) SetState(s *string) {
	switch *s {
	case "local", "localhost", "l":
		cv.State = stateLocal
	case "dev", "develop", "development", "d":
		cv.State = stateDEV
	case "sit", "staging", "s":
		cv.State = stateSIT
	case "prod", "production", "p":
		cv.State = statePROD
	default:
		cv.State = stateLocal
	}
}

func (cv *constantViper) Init() {
	viper.SetConfigFile("config.yml")
	viper.AddConfigPath(".")
	if err := viper.ReadInConfig(); err != nil {
		panic(err)
	}

	sub := viper.Sub(string(cv.State))

	cv.ProjectCode = sub.GetString("project_code")
}
