package square

type Rectangle struct {
	width  float64
	height float64
}
