package main

import (
	"fmt"
	"sync"

	"teebasic/square"
)

type Student struct {
	FirstName string
	LastName  string
	grade     int
}

func (s *Student) Name() string {
	return fmt.Sprintf("%s %s", s.FirstName, s.LastName)
}

func main() {

	s := Student{
		FirstName: "muz",
		LastName:  "Teo",
		grade:     0,
	}
	fmt.Printf("%+v", s)
	fmt.Println(s.Name())

	square := Rectangle{
		width:  4.0,
		height: 4.0,
	}
	fmt.Println(square)
}
