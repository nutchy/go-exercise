package main

import (
	"encoding/xml"
	"io/ioutil"
	"log"
	"time"
)

func main() {
	data, err := ioutil.ReadFile("./books.xml")
	if err != nil {
		log.Println("error:", err)
		return
	}
	log.Println("data:", string(data))

	var c catalog
	if err := xml.Unmarshal(data, &c); err != nil {
		return
	}
	log.Println("c:", c)
}

type catalog struct {
	Catalog []book `xml:"catalog"`
}

type book struct {
	Author      string    `xml:"author"`
	Title       string    `xml:"title"`
	Genre       string    `xml:"genre"`
	Price       float64   `xml:"price"`
	PublishDate time.Time `xml:"publish_date"`
	Description string    `xml:"description"`
}
