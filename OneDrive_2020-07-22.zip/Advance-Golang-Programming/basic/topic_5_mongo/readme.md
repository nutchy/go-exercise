# MongoDB

## Basic Connection
```go
func basicMongo() error {
    dialInfo := mgo.DialInfo{
        Addrs:    []string{"127.0.0.1"},
        Timeout:  5 * time.Second,
        Database: mongoDBName,
        Username: "",
        Password: "",
    }
    
    sess, err := mgo.DialWithInfo(&dialInfo)
    if err != nil {
        return err
    }
    defer sess.Close()
    
    db := sess.DB("{database_name}").C("{collection}")
    
    // find one record
    var rtn1 interface{}
    if err := db.Find(nil).One(&rtn1); err != nil {
        return err
    }
    
    // find multi records
    var rtn2 []interface{}
    if err := db.Find(nil).All(&rtn2); err != nil {
        return err
    }
    
    // update one record
    if err := db.Update(bson.M{"": ""}, bson.M{"": ""}); err != nil {
        return err
    }
    
    // update multi records
    if _, err := db.UpdateAll(bson.M{"": ""}, bson.M{"": ""}); err != nil {
        return err
    }
    
    // delete one record
    if err := db.Remove(bson.M{"": ""}); err != nil {
        return err
    }
    
    // delete multi record
    if _, err := db.RemoveAll(bson.M{"": ""}); err != nil {
        return err
    }
    
    return nil
}
```

## Bulk
```go
func bulkMongo() error {
	sess, err := mgo.DialWithInfo(&dialInfo)
	if err != nil {
		return err
	}
	defer sess.Close()

	db := sess.DB("{database_name}").C("{collection}")

	type data struct {
		Name     string `bson:"customer_name,omitempty"`
		MobileNo string `bson:"mobile_no,omitempty"`
	}

	rs := []data{
		{"mike", "0812345678"},
		{"steve", "0898765432"},
	}

	b := db.Bulk()
	for _, d := range rs {
		b.Insert(d)
	}
	if _, err := b.Run(); err != nil {
		return err
	}
	return nil
}
```

## Middleware
```go
func getDB(c *gin.Context) (*mgo.Database, error) {
	sess, ok := c.Keys[mongoContext].(*mgo.Session)
	if !ok {
		return nil, mongoNotFound
	}
	return sess.DB(mongoDBName), nil
}

func mongoMiddleware() gin.HandlerFunc {
	main, err := mgo.DialWithInfo(&dialInfo)
	if err != nil {
		panic(err)
	}

	return func(c *gin.Context) {
		sess := main.Clone()
		defer sess.Close()

		c.Set(mongoContext, sess)
		c.Next()
	}
}

func contextMongo(c *gin.Context) {
	mongo, err := getDB(c)
	if err != nil {
		c.JSON(http.StatusServiceUnavailable, gin.H{"message": err})
		return
	}

	var m merchant
	if err := mongo.C("merchants").Find(bson.M{"email": "merchant02@kasikornbank.com"}).One(&m); err != nil {
		c.JSON(http.StatusOK, gin.H{"message": "merchant not found"})
	}

	c.JSON(http.StatusOK, m)
}
```

