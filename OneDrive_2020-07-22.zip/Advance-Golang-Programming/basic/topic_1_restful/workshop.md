# workshop
***task 1:*** calculate grade

***endpoint:*** http://localhost:8000/task_one?point=61

***response:***
```json
{
    "point": 61,
    "grade": "D"
}
```
---
***task 2:*** separate paragraph message and sort wording by length as response

***endpoint:*** localhost:8000/task_two

***request:***
```json
{
    "message": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
}
```

***response:***
```json
[
    {
        "word": "ad",
        "length": 2
    },
    {
        "word": "in",
        "length": 2
    },
    {
        "word": "eu",
        "length": 2
    },
    {
        "word": "et",
        "length": 2
    },
    {
        "word": "in",
        "length": 2
    },
    {
        "word": "ut",
        "length": 2
    },
    {
        "word": "id",
        "length": 2
    },
    {
        "word": "in",
        "length": 2
    },
    {
        "word": "Ut",
        "length": 2
    },
    {
        "word": "do",
        "length": 2
    },
    {
        "word": "ex",
        "length": 2
    },
    {
        "word": "ut",
        "length": 2
    },
    {
        "word": "ea",
        "length": 2
    },
    {
        "word": "est",
        "length": 3
    },
    {
        "word": "qui",
        "length": 3
    },
    {
        "word": "sit",
        "length": 3
    },
    {
        "word": "sed",
        "length": 3
    },
    {
        "word": "non",
        "length": 3
    },
    {
        "word": "anim",
        "length": 4
    },
    {
        "word": "Duis",
        "length": 4
    },
    {
        "word": "enim",
        "length": 4
    },
    {
        "word": "sint",
        "length": 4
    },
    {
        "word": "esse",
        "length": 4
    },
    {
        "word": "sunt",
        "length": 4
    },
    {
        "word": "quis",
        "length": 4
    },
    {
        "word": "nisi",
        "length": 4
    },
    {
        "word": "aute",
        "length": 4
    },
    {
        "word": "nulla",
        "length": 5
    },
    {
        "word": "amet,",
        "length": 5
    },
    {
        "word": "ipsum",
        "length": 5
    },
    {
        "word": "elit,",
        "length": 5
    },
    {
        "word": "minim",
        "length": 5
    },
    {
        "word": "dolor",
        "length": 5
    },
    {
        "word": "culpa",
        "length": 5
    },
    {
        "word": "Lorem",
        "length": 5
    },
    {
        "word": "dolor",
        "length": 5
    },
    {
        "word": "magna",
        "length": 5
    },
    {
        "word": "irure",
        "length": 5
    },
    {
        "word": "velit",
        "length": 5
    },
    {
        "word": "mollit",
        "length": 6
    },
    {
        "word": "tempor",
        "length": 6
    },
    {
        "word": "cillum",
        "length": 6
    },
    {
        "word": "labore",
        "length": 6
    },
    {
        "word": "dolore",
        "length": 6
    },
    {
        "word": "fugiat",
        "length": 6
    },
    {
        "word": "dolore",
        "length": 6
    },
    {
        "word": "officia",
        "length": 7
    },
    {
        "word": "ullamco",
        "length": 7
    },
    {
        "word": "eiusmod",
        "length": 7
    },
    {
        "word": "aliquip",
        "length": 7
    },
    {
        "word": "laboris",
        "length": 7
    },
    {
        "word": "nostrud",
        "length": 7
    },
    {
        "word": "veniam,",
        "length": 7
    },
    {
        "word": "aliqua.",
        "length": 7
    },
    {
        "word": "commodo",
        "length": 7
    },
    {
        "word": "laborum.",
        "length": 8
    },
    {
        "word": "occaecat",
        "length": 8
    },
    {
        "word": "deserunt",
        "length": 8
    },
    {
        "word": "proident,",
        "length": 9
    },
    {
        "word": "Excepteur",
        "length": 9
    },
    {
        "word": "pariatur.",
        "length": 9
    },
    {
        "word": "voluptate",
        "length": 9
    },
    {
        "word": "cupidatat",
        "length": 9
    },
    {
        "word": "consequat.",
        "length": 10
    },
    {
        "word": "incididunt",
        "length": 10
    },
    {
        "word": "adipiscing",
        "length": 10
    },
    {
        "word": "consectetur",
        "length": 11
    },
    {
        "word": "exercitation",
        "length": 12
    },
    {
        "word": "reprehenderit",
        "length": 13
    }
]
```
