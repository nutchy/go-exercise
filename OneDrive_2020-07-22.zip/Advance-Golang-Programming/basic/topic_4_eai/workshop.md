### parse xml
```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v2="http://eai.kasikornbank.com/EAIWS/CBS1182F01/v2">
    <soapenv:Body>
        <doService xmlns="http://eai.kasikornbank.com/EAIWS/CBS1182F01/v2">
            <CBS1182F01>
                <KBankHeader>
                    <funcNm>CBS1182F01</funcNm>
                    <rqUID>733_20180608_1430_0000001</rqUID>
                    <rqAppId>733</rqAppId>
                    <rqDt>2018-06-08T14:34:09.47479164+07:00</rqDt>
                    <corrID>3434</corrID>
                    <userId>KPP20029</userId>
                    <terminalId>733</terminalId>
                    <userLangPref>TH</userLangPref>
                    <authUserId>KPP20029</authUserId>
                    <authLevel>1</authLevel>
                    <errorVect>
                        <error></error>
                    </errorVect>
                </KBankHeader>
                <CBSAccount>
                    <AcctId>6722044965</AcctId>
                    <Concept1>CR To 6722044965</Concept1>
                    <Concept2></Concept2>
                    <ExtAcctDt>2018-02-01</ExtAcctDt>
                    <FeeAmt>0.0</FeeAmt>
                    <ICA>733</ICA>
                    <OperationCode>01</OperationCode>
                    <OperationType>CR</OperationType>
                    <SubOperationCode>0900</SubOperationCode>
                    <SvcBranchId>0923</SvcBranchId>
                    <TrnAmt>300</TrnAmt>
                    <UseSvcBranchFlag>N</UseSvcBranchFlag>
                    <ValueDt>2018-02-01</ValueDt>
                    <AuthLevCnt></AuthLevCnt>
                    <TellerID></TellerID>
                    <TellerIDAuthNum></TellerIDAuthNum>
                    <TxnCode></TxnCode>
                    <TxnIndctcnt></TxnIndctcnt>                    
                </CBSAccount>
            </CBS1182F01>
        </doService>
    </soapenv:Body>
</soapenv:Envelope>
```
