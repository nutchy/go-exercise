package main

import (
	"encoding/xml"
	log "github.com/sirupsen/logrus"
	"time"
	//"kbtg.tech/prepaid/go-eai"
)

func main() {
	parseXML()
}

//func lib() {
//	tn := time.Now()
//	header := eai.KBankHeader{
//		FuncNum:       "",
//		RequestUID:    generateRandomID(),
//		RequestAppID:  "",
//		RequestDate:   &tn,
//		ResponseAppID: "",
//		CorrID:        "",
//		UserID:        "",
//		TerminalID:    "",
//		UserLangPref:  "",
//		AuthUserID:    "",
//		AuthLevel:     "",
//	}
//
//	body := eai.CBS1182F01{
//		AccountID:         "",
//		Concept1:          "",
//		Concept2:          "",
//		ExtAccountDate:    "",
//		FeeAmount:         "",
//		ICA:               "",
//		OperationCode:     "",
//		SubOperationCode:  "",
//		OperationType:     "",
//		SVCBranchID:       "",
//		UseSVCBranchFlag:  "",
//		ValueDate:         "",
//		TransactionAmount: 0.0,
//	}
//
//	conf := eai.Config{
//		URL:      eai.URL{SOAP1182F01: "http://127.0.0.1:9999/EAIWS/CBS1182F01.jws"},
//		Username: "",
//		Password: "",
//	}
//	ec := eai.NewClient(&conf)
//
//	rh, rb, err := ec.CBS1182F01Request(header, body)
//	if err != nil {
//		log.Errorf("call CBS1182F01 error: %+v %+v %s", header, body, err)
//		return
//	}
//	log.Infof("response header: %+v", rh)
//	log.Infof("response body: %+v", rb)
//}
//
//func generateRandomID() string {
//	r := rand.New(rand.NewSource(time.Now().UnixNano()))
//	d := time.Now().Format("20060102")
//	t := time.Now().Format("030405")
//	s := r.Int31()
//
//	return fmt.Sprintf("733_%s_%s_%d", d, t, s)
//}

func parseXML() {
	xd := `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v2="http://eai.kasikornbank.com/EAIWS/CBS1189I01/v2">
    <soapenv:Body>
        <doService xmlns="http://eai.kasikornbank.com/EAIWS/CBS1189I01/v2">
            <CBS1189I01>
                <KBankHeader>
                    <funcNm>CBS1189I01</funcNm>
                    <rqUID>733_20180608_1430_0000001</rqUID>
                    <rqAppId>733</rqAppId>
                    <rqDt>2018-06-08T14:34:09.47479164+07:00</rqDt>
                    <corrID>3434</corrID>
                    <userId>KPP00001</userId>
                    <terminalId>733</terminalId>
                    <userLangPref>th</userLangPref>
                    <authUserId>KBANKPP</authUserId>
                    <authLevel>1</authLevel>
                    <errorVect>
                        <error></error>
                    </errorVect>
                </KBankHeader>
                <CBSAccount>
                    <AcctId>0012000553</AcctId>
                </CBSAccount>
            </CBS1189I01>
        </doService>
    </soapenv:Body>
</soapenv:Envelope>`

	var res CBS1189I011
	if err := xml.Unmarshal([]byte(xd), &res); err != nil {
		log.Errorln("xml unmarshal error:", err)
		return
	}

	//res.Body.DoService.CBS1189I01.KBankHeader.UserID

	log.Printf("res: %+v", res)
	log.Println("account id:", res.AccountID)
	log.Println("request time:", res.RqDate, res.RqDate.AddDate(0, 0, 1))
	//log.Println("account id:", res.Body.DoService.CBS1189I01.CBSAccount.AccountID)

	//log.Println("account id:", res.Body.DoService.CBS1189I01.CBSAccount.AccountID)
	//res.AccountID
	//res.Body.DoService.CBS1189I01.CBSAccount.AccountID
}

type CBS1189I010 struct {
	Body struct {
		DoService struct {
			CBS1189I01 struct {
				KBankHeader struct {
					FunctionName string `xml:"funcNm"`
					RequestUID   string `xml:"rqUID"`
					RequestAppID string `xml:"rqAppId"`
					RequestDate  string `xml:"rqDt"`
					CorrID       string `xml:"corrID"`
					UserID       string `xml:"userId"`
					TerminalID   string `xml:"terminalId"`
					UserLanguage string `xml:"userLangPref"`
					AuthenUserID string `xml:"authUserId"`
					AuthenLevel  string `xml:"authLevel"`
				} `xml:"KBankHeader"`
				CBSAccount struct {
					AccountID string `xml:"AcctId"`
				} `xml:"CBSAccount"`
			} `xml:"CBS1189I01"`
		} `xml:"doService"`
	} `xml:"Body"`
}

type CBS1189I011 struct {
	SOAPEnvAttribute string    `xml:"soapenv,attr"`
	SOAPV2Attribute  string    `xml:"v2,attr"`
	FuncName         string    `xml:"Body>doService>CBS1189I01>KBankHeader>funcNm"`
	QRUID            string    `xml:"Body>doService>CBS1189I01>KBankHeader>rqUID"`
	AppID            int       `xml:"Body>doService>CBS1189I01>KBankHeader>rqAppId"`
	RqDate           time.Time `xml:"Body>doService>CBS1189I01>KBankHeader>rqDt"`
	CorrID           string    `xml:"Body>doService>CBS1189I01>KBankHeader>corrID"`
	UserID           string    `xml:"Body>doService>CBS1189I01>KBankHeader>userId"`
	TerminalID       string    `xml:"Body>doService>CBS1189I01>KBankHeader>terminalId"`
	UserLanguage     string    `xml:"Body>doService>CBS1189I01>KBankHeader>userLangPref"`
	AuthenUserID     string    `xml:"Body>doService>CBS1189I01>KBankHeader>authUserId"`
	AuthenLevel      int       `xml:"Body>doService>CBS1189I01>KBankHeader>authLevel"`
	AccountID        string    `xml:"Body>doService>CBS1189I01>CBSAccount>AcctId"`
}
