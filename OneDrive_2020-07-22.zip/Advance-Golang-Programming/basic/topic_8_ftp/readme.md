# FTP File Transfer

- use control-m
- manual file transfer
- send email
    - text body
    - html body
    
## Manual File Transfer
### upload
```go
func uploadFileFTP(name string) error {
	config := ssh.ClientConfig{
		User: "{ftp_username}",
		Auth: []ssh.AuthMethod{ssh.Password("{ftp_password}")},
	}
	client, err := ssh.Dial("tcp", "{ftp_host}", &config)
	if err != nil {
		return err
	}
	defer client.Close()

	ftp, err := sftp.NewClient(client)
	if err != nil {
		return err
	}
	defer ftp.Close()

	// read local file
	local := filepath.Join("local", "path", name)
	data, err := ioutil.ReadFile(local)
	if err != nil {
		return err
	}

	// create file on ftp
	fp := filepath.Join("ftp", "path", name)
	f, err := ftp.Create(fp)
	if err != nil {
		return err
	}
	defer f.Close()

	// write data to ftp file
	if _, err := f.Write(data); err != nil {
		return err
	}

	// check file is created on ftp server
	fi, err := ftp.Lstat(fp)
	if err != nil {
		return err
	}
	log.Printf("check file: %+v", fi)

	return nil
}
```

### download
```go
func downloadFileFTP(name string) error {
	config := ssh.ClientConfig{
		User: "{ftp_username}",
		Auth: []ssh.AuthMethod{ssh.Password("{ftp_password}")},
	}
	client, err := ssh.Dial("tcp", "{ftp_host}", &config)
	if err != nil {
		return err
	}
	defer client.Close()

	ftp, err := sftp.NewClient(client)
	if err != nil {
		return err
	}
	defer ftp.Close()

	// open ftp file
	fp := filepath.Join("ftp", "path", name)
	r, err := ftp.Open(fp)
	if err != nil {
		return err
	}
	defer r.Close()

	// read data in ftp file
	data, err := ioutil.ReadAll(r)
	if err != nil {
		return err
	}

	// create file on local
	local := filepath.Join("local", "path", name)
	f, err := os.Create(local)
	if err != nil {
		return err
	}
	defer f.Close()

	// write data on local file
	if _, err := f.Write(data); err != nil {
		return err
	}

	return nil
}
```

### create zip file
```go
func createZip(source, target string) error {
	f, err := os.Create(target)
	if err != nil {
		return err
	}
	defer f.Close()

	zw := zip.NewWriter(f)
	defer zw.Close()

	// walk trough file to zip one by one
	err = filepath.Walk(source, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			log.Errorln("prevent panic by handling failure accessing a path: %q: %v", source, err)
			return err
		}

		// read zip file header
		header, err := zip.FileInfoHeader(info)
		if err != nil {
			return err
		}

		// Change to deflate to gain better compression
		// see http://golang.org/pkg/archive/zip/#pkg-constants
		header.Method = zip.Deflate

		// create zip file header
		w, err := zw.CreateHeader(header)
		if err != nil {
			return err
		}

		// open local file in path
		fi, err := os.Open(path)
		if err != nil {
			return err
		}
		defer fi.Close()

		// copy local file to zip file header
		if _, err := io.Copy(w, fi); err != nil {
			return err
		}

		return nil
	})
	if err != nil {
		return err
	}

	return nil
}
```

### unzip
```go
func unzip(source, target string) error {
	r, err := zip.OpenReader(source)
	if err != nil {
		return err
	}
	defer r.Close()

	// create target directory if not exists
	if err := os.MkdirAll(target, os.ModePerm); err != nil {
		return err
	}

	createFile := func(file *zip.File) error {
		path := filepath.Join(target, file.Name)
		if file.FileInfo().IsDir() {
			os.MkdirAll(path, file.Mode())
			return nil
		}

		// open zip file
		fr, err := file.Open()
		if err != nil {
			return err
		}
		defer fr.Close()

		// open/create local file
		t, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, file.Mode())
		if err != nil {
			return err
		}
		defer t.Close()

		// copy data from zip file to local file
		if _, err := io.Copy(t, fr); err != nil {
			return err
		}

		return nil
	}

	for _, f := range r.File {
		if err := createFile(f); err != nil {
			log.Errorln("unable to create file:", f.Name, err)
			continue
		}
	}

	return nil
}
```

## Email

```go
func sendEmail(subject, message string, emailType int, recipient, attachments []string) error {
	var content *email.Message
	switch emailType {
	case emailText:
		content = email.NewMessage(subject, message)
	case emailHTML:
		content = email.NewHTMLMessage(subject, message)
	default:
		return errors.New("invalid email type")
	}

	content.From = mail.Address{Name: "{sender name}", Address: "{sender@mail.com}"}
	content.To = recipient

	for _, a := range attachments {
		if a == "" {
			continue
		}

		if err := content.Attach(a); err != nil {
			log.Errorln("unable to attach file:", a, err)
			continue
		}
	}

	return email.Send("{email_gateway}", nil, content)
}
```

### Text Message
```go
func sendTextEmail() error {
	topic := "รหัสผ่านชั่วคราว"
	message := `รหัสผ่านชั่วคราวของคุณคือ "123456"`

	return sendEmail(topic, message, emailText, []string{"{receiver@mail.com}"}, nil)
}
```

### HTML Message
```go
func sendHTMLEmail() error {
	ev := struct {
		Name              string
		RefNo             string
		TemporaryPassword string
	}{"ทดสอบ", "123456", "abcdefg"}

	tmpl, err := ht.ParseFiles(filepath.Join("template", "pin.tmpl"))
	if err != nil {
		return err
	}

	var buff bytes.Buffer
	if err := tmpl.Execute(&buff, ev); err != nil {
		return err
	}

	topic := "รหัสผ่านชั่วคราว"
	return sendEmail(topic, buff.String(), emailHTML, []string{"{receiver@mail.com}"}, nil)
}
```
