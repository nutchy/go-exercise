package main

import (
	"database/sql"
	"encoding/json"
	"log"
	"net/http"

	"github.com/dustin/go-humanize"
	"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
)

func main() {
	//basicHttp()
	advancedHttp()
}

func basicHttp() {
	r := gin.Default()
	r.GET("/db_version", dbVersionEndpoint)
	r.Run()
}

func dbVersionEndpoint(c *gin.Context) {
	db, err := sql.Open("mysql", "root:password@tcp(mariadb)/")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"db error": err})
		return
	}
	defer db.Close()

	if err := db.Ping(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"ping error": err})
		return
	}

	var version string
	db.QueryRow("SELECT VERSION()").Scan(&version)
	c.JSON(http.StatusOK, gin.H{"connected to": version})
}

func advancedHttp() {
	middleware := func() gin.HandlerFunc {
		db, err := sql.Open("mysql", "root:password@tcp(mariadb)/world")
		if err != nil {
			panic(err)
		}

		return func(c *gin.Context) {
			c.Set("mariadb", db)
			c.Next()
		}
	}

	r := gin.Default()
	r.Use(middleware())
	r.GET("/db_version", dbVersionEndpointV2)
	r.GET("/world", worldEndpoint)
	r.GET("/world_paging", worldPagingEndpoint)
	r.Run()
}

func dbVersionEndpointV2(c *gin.Context) {
	db := c.Keys["mariadb"].(*sql.DB)
	if err := db.Ping(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"ping error": err})
		return
	}

	var version string
	db.QueryRow("SELECT VERSION()").Scan(&version)
	c.JSON(http.StatusOK, gin.H{"connected to": version})
}

type city struct {
	ID          string     `json:"id"`
	Name        string     `json:"name"`
	CountryCode string     `json:"country_code"`
	District    string     `json:"district"`
	Population  population `json:"population"`
}

type population int

func (p population) MarshalJSON() ([]byte, error) {
	return json.Marshal(humanize.Comma(int64(p)))
}

func worldEndpoint(c *gin.Context) {
	db := c.Keys["mariadb"].(*sql.DB)
	if err := db.Ping(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"message": "unable to connect db"})
		return
	}

	rows, err := db.Query("SELECT * FROM city")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"query error": err})
		return
	}
	defer rows.Close()

	var data city
	var res []city
	for rows.Next() {
		if err := rows.Scan(&data.ID, &data.Name, &data.CountryCode, &data.District, &data.Population); err != nil {
			log.Println("rows scan error:", err)
			continue
		}
		res = append(res, data)
	}
	if rows.Err() != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"rows error": err})
		return
	}

	c.JSON(http.StatusOK, res)
}

func worldPagingEndpoint(c *gin.Context) {
	db := c.Keys["mariadb"].(*sql.DB)
	if err := db.Ping(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"ping error": err})
		return
	}

	last := c.Query("last")
	if last == "" {
		last = "0"
	}

	limit := c.Query("limit")
	if limit == "" {
		limit = "10"
	}

	stmt, err := db.Prepare("SELECT * FROM city WHERE id > ? LIMIT ?")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"prepare error": err})
		return
	}
	defer stmt.Close()

	rows, err := stmt.Query(last, limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"rows error": err})
		return
	}
	defer rows.Close()

	var data city
	var res []city
	for rows.Next() {
		if err := rows.Scan(&data.ID, &data.Name, &data.CountryCode, &data.District, &data.Population); err != nil {
			log.Println("rows scan error:", err)
			continue
		}
		res = append(res, data)
	}
	if rows.Err() != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"rows error": err})
		return
	}

	c.JSON(http.StatusOK, res)
}
