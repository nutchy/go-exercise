#!/bin/bash

echo "=> Importing example database 'world'"
unzip world.sql.zip
mysql -uroot -p${MYSQL_ROOT_PASSWORD} -e "CREATE DATABASE world"
mysql -uroot -p${MYSQL_ROOT_PASSWORD} world < world.sql

echo "=> Granting access to all databases for '${MYSQL_USER}'"
mysql -uroot -p${MYSQL_ROOT_PASSWORD} -e "GRANT ALL PRIVILEGES ON *.* TO '${MYSQL_USER}'@'%' WITH GRANT OPTION"

echo "=> Done!"
