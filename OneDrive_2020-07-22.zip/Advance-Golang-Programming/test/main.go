package main

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"
)

func main() {
	//	str := `Sun 10:00-20:00
	//Fri 05:00-10:00
	//Fri 16:30-23:50
	//Sat 10:00-24:00
	//Sun 01:00-04:00
	//Sat 02:00-06:00
	//Tue 03:30-18:15
	//Tue 19:00-20:00
	//Wed 04:25-15:14
	//Wed 15:14-22:40
	//Thu 00:00-23:59
	//Mon 05:00-13:00
	//Mon 15:00-21:00`
	str := `Mon 01:00-23:00
Tue 01:00-23:00
Wed 01:00-23:00
Thu 01:00-23:00
Fri 01:00-23:00
Sat 01:00-23:00
Sun 01:00-21:00`

	ms, _ := parseMeeting(str)

	// add corner
	ms = append(ms, meeting{0, parseDate("Mon", 0, 0), parseDate("Mon", 0, 0), 0})
	ms = append(ms, meeting{6, parseDate("Sun", 24, 0), parseDate("Sun", 24, 0), 0})

	sort.Sort(meetingSort(ms))

	for _, m := range ms {
		fmt.Println(m, m.Duration.Minutes())
	}

	var rtn time.Duration
	for i := 0; i < len(ms)-1; i++ {
		//fmt.Println(ms[i+1], ms[i], ms[i+1].Start.Sub(ms[i].End).Minutes())

		t := ms[i+1].Start.Sub(ms[i].End)
		if t > rtn {
			rtn = t
		}
	}
	fmt.Println(rtn.Minutes())

}

type meetingSort []meeting

func (ms meetingSort) Swap(i, j int) {
	ms[i], ms[j] = ms[j], ms[i]
}

func (ms meetingSort) Less(i, j int) bool {
	if ms[i].Date < ms[j].Date {
		return true
	}

	if ms[i].Date == ms[j].Date && ms[i].Start.Before(ms[j].Start) {
		return true
	}

	return false
}

func (ms meetingSort) Len() int {
	return len(ms)
}

type meeting struct {
	Date     int
	Start    time.Time
	End      time.Time
	Duration time.Duration
}

func parseMeeting(str string) ([]meeting, error) {
	var rtn []meeting

	ds := strings.Split(str, "\n")
	for _, d := range ds {
		day := d[0:3]
		sh, err := strconv.Atoi(d[4:6])
		if err != nil {
			return nil, err
		}
		sm, err := strconv.Atoi(d[7:9])
		if err != nil {
			return nil, err
		}

		eh, err := strconv.Atoi(d[10:12])
		if err != nil {
			return nil, err
		}
		em, err := strconv.Atoi(d[13:15])
		if err != nil {
			return nil, err
		}

		start := parseDate(day, sh, sm)
		end := parseDate(day, eh, em)

		rtn = append(rtn, meeting{parseDay(day), start, end, end.Sub(start)})
	}
	return rtn, nil
}

func parseDate(d string, hour, mintue int) time.Time {
	// assume today as monday
	tn := time.Now()
	switch d {
	case "Mon":
		// do nothing
	case "Tue":
		tn = tn.AddDate(0, 0, 1)
	case "Wed":
		tn = tn.AddDate(0, 0, 2)
	case "Thu":
		tn = tn.AddDate(0, 0, 3)
	case "Fri":
		tn = tn.AddDate(0, 0, 4)
	case "Sat":
		tn = tn.AddDate(0, 0, 5)
	case "Sun":
		tn = tn.AddDate(0, 0, 6)
	}
	return time.Date(tn.Year(), tn.Month(), tn.Day(), hour, mintue, 0, 0, tn.Location())
}

func parseDay(d string) int {
	switch d {
	case "Mon":
		return 0
	case "Tue":
		return 1
	case "Wed":
		return 2
	case "Thu":
		return 3
	case "Fri":
		return 4
	case "Sat":
		return 5
	case "Sun":
		return 6
	}
	return 0
}
